import { GoogleGenAI, Type } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function askAssistant(text: string, audioBlob: Blob | null, history: any[]): Promise<{ text: string, audioBase64?: string, newHistory: any[] }> {
  const parts: any[] = [];
  
  if (audioBlob) {
    const base64Audio = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
      reader.readAsDataURL(audioBlob);
    });
    parts.push({
      inlineData: {
        data: base64Audio,
        mimeType: audioBlob.type,
      }
    });
  }
  
  if (text) {
    parts.push({ text });
  }

  const currentMessage = { role: 'user', parts };
  const fullHistory = [...history, currentMessage];

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: fullHistory,
    config: {
      systemInstruction: "You are PlantCare AI, a helpful and expert botanical voice assistant. Answer questions about plant care, diseases, and fertilizers concisely and conversationally. Keep your answers relatively short so they are easy to listen to.",
    }
  });

  const textResponse = response.text || "I'm sorry, I couldn't process that.";
  const assistantMessage = { role: 'model', parts: [{ text: textResponse }] };

  let audioResponseBase64;
  try {
    const ttsResponse = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: textResponse }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
        },
      },
    });
    audioResponseBase64 = ttsResponse.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (e) {
    console.error("TTS failed", e);
  }

  return { 
    text: textResponse, 
    audioBase64: audioResponseBase64,
    newHistory: [...fullHistory, assistantMessage]
  };
}

export async function analyzePlantImage(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = async () => {
      try {
        const base64Data = (reader.result as string).split(',')[1];
        
        const response = await ai.models.generateContent({
          model: 'gemini-3-flash-preview',
          contents: [
            {
              inlineData: {
                data: base64Data,
                mimeType: file.type,
              },
            },
            {
              text: 'You are an expert botanist and plant pathologist. Analyze this image of a plant leaf. Identify the plant and any diseases present. Provide a diagnosis, actionable treatment advice, and specific fertilizer or soil amendment recommendations to help the plant recover or thrive. If the image is not a plant, state that it is not a plant.',
            },
          ],
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                isPlant: {
                  type: Type.BOOLEAN,
                  description: 'Whether the image contains a plant or plant leaf.',
                },
                plantName: {
                  type: Type.STRING,
                  description: 'The name of the plant.',
                },
                disease: {
                  type: Type.STRING,
                  description: 'The name of the disease, or "Healthy" if no disease is detected.',
                },
                confidence: {
                  type: Type.NUMBER,
                  description: 'Confidence score between 0 and 100.',
                },
                description: {
                  type: Type.STRING,
                  description: 'A brief description of the diagnosis.',
                },
                treatment: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.STRING,
                  },
                  description: 'Actionable treatment advice or recommendations.',
                },
                fertilizers: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.STRING,
                  },
                  description: 'Specific fertilizer or soil amendment recommendations.',
                },
              },
              required: ['isPlant', 'plantName', 'disease', 'confidence', 'description', 'treatment', 'fertilizers'],
            },
          },
        });

        const result = JSON.parse(response.text || '{}');
        resolve(result);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}
