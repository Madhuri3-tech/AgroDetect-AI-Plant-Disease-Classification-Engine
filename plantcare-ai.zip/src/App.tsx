import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Leaf, UploadCloud, Info, Home, ArrowRight, CheckCircle, AlertTriangle, Camera, X, Mic, Square, Volume2, Send, MessageSquare, Sprout } from 'lucide-react';
import { analyzePlantImage, askAssistant } from './services/geminiService';

type Page = 'home' | 'about' | 'upload' | 'result' | 'assistant';

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  // Assistant State
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [chatMessages, setChatMessages] = useState<{role: 'user' | 'assistant', text: string, audio?: string}[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessingVoice, setIsProcessingVoice] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [textInput, setTextInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  React.useEffect(() => {
    if (currentPage === 'assistant') {
      scrollToBottom();
    }
  }, [chatMessages, currentPage]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        stream.getTracks().forEach(track => track.stop());
        await handleVoiceSubmit(audioBlob);
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err) {
      console.error("Error accessing microphone:", err);
      setError("Could not access microphone. Please check permissions.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const playAudio = async (base64Audio: string) => {
    try {
      const binaryString = window.atob(base64Audio);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const float32Data = new Float32Array(bytes.length / 2);
      const dataView = new DataView(bytes.buffer);
      for (let i = 0; i < float32Data.length; i++) {
        float32Data[i] = dataView.getInt16(i * 2, true) / 32768.0;
      }
      
      const audioBuffer = audioContext.createBuffer(1, float32Data.length, 24000);
      audioBuffer.getChannelData(0).set(float32Data);
      
      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContext.destination);
      source.start();
    } catch (e) {
      console.error("Error playing audio:", e);
    }
  };

  const handleVoiceSubmit = async (audioBlob: Blob) => {
    setIsProcessingVoice(true);
    const newMessages = [...chatMessages, { role: 'user' as const, text: '🎤 (Voice Message)' }];
    setChatMessages(newMessages);

    try {
      const result = await askAssistant('', audioBlob, chatHistory);
      setChatHistory(result.newHistory);
      setChatMessages([
        ...newMessages,
        { role: 'assistant', text: result.text, audio: result.audioBase64 }
      ]);
      
      if (result.audioBase64) {
        playAudio(result.audioBase64);
      }
    } catch (err) {
      console.error("Assistant error:", err);
      setChatMessages([
        ...newMessages,
        { role: 'assistant', text: "Sorry, I encountered an error processing your request." }
      ]);
    } finally {
      setIsProcessingVoice(false);
    }
  };

  const handleTextSubmit = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!textInput.trim()) return;

    const currentText = textInput;
    setTextInput('');
    setIsProcessingVoice(true);
    
    const newMessages = [...chatMessages, { role: 'user' as const, text: currentText }];
    setChatMessages(newMessages);

    try {
      const result = await askAssistant(currentText, null, chatHistory);
      setChatHistory(result.newHistory);
      setChatMessages([
        ...newMessages,
        { role: 'assistant', text: result.text, audio: result.audioBase64 }
      ]);
      
      if (result.audioBase64) {
        playAudio(result.audioBase64);
      }
    } catch (err) {
      console.error("Assistant error:", err);
      setChatMessages([
        ...newMessages,
        { role: 'assistant', text: "Sorry, I encountered an error processing your request." }
      ]);
    } finally {
      setIsProcessingVoice(false);
    }
  };

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  const handleImageSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file.');
      return;
    }
    setError(null);
    setSelectedImage(file);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImagePreview(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    if (!selectedImage) return;
    
    setIsAnalyzing(true);
    setError(null);
    
    try {
      const result = await analyzePlantImage(selectedImage);
      setAnalysisResult(result);
      navigateTo('result');
    } catch (err) {
      console.error('Analysis failed:', err);
      setError('Failed to analyze the image. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetUpload = () => {
    setSelectedImage(null);
    setImagePreview(null);
    setAnalysisResult(null);
    setError(null);
    navigateTo('upload');
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 font-sans flex flex-col">
      {/* Navigation */}
      <nav className="bg-white border-b border-stone-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center cursor-pointer" onClick={() => navigateTo('home')}>
              <Leaf className="h-8 w-8 text-emerald-600" />
              <span className="ml-2 text-xl font-bold text-stone-800 tracking-tight">PlantCare AI</span>
            </div>
            <div className="flex items-center space-x-4 sm:space-x-8">
              <button 
                onClick={() => navigateTo('home')}
                className={`flex items-center text-sm font-medium transition-colors ${currentPage === 'home' ? 'text-emerald-600' : 'text-stone-500 hover:text-stone-900'}`}
              >
                <Home className="h-4 w-4 mr-1 hidden sm:block" />
                Home
              </button>
              <button 
                onClick={() => navigateTo('about')}
                className={`flex items-center text-sm font-medium transition-colors ${currentPage === 'about' ? 'text-emerald-600' : 'text-stone-500 hover:text-stone-900'}`}
              >
                <Info className="h-4 w-4 mr-1 hidden sm:block" />
                About
              </button>
              <button 
                onClick={() => navigateTo('upload')}
                className={`flex items-center text-sm font-medium transition-colors ${currentPage === 'upload' || currentPage === 'result' ? 'text-emerald-600' : 'text-stone-500 hover:text-stone-900'}`}
              >
                <UploadCloud className="h-4 w-4 mr-1 hidden sm:block" />
                Upload
              </button>
              <button 
                onClick={() => navigateTo('assistant')}
                className={`flex items-center text-sm font-medium transition-colors ${currentPage === 'assistant' ? 'text-emerald-600' : 'text-stone-500 hover:text-stone-900'}`}
              >
                <MessageSquare className="h-4 w-4 mr-1 hidden sm:block" />
                Assistant
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-grow flex flex-col">
        <AnimatePresence mode="wait">
          {currentPage === 'home' && (
            <motion.div
              key="home"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="flex-grow flex flex-col items-center justify-center px-4 py-12 sm:px-6 lg:px-8"
            >
              <div className="max-w-3xl text-center">
                <div className="inline-flex items-center justify-center p-3 bg-emerald-100 rounded-full mb-6">
                  <Leaf className="h-10 w-10 text-emerald-600" />
                </div>
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-stone-900 tracking-tight mb-6">
                  Detect Plant Diseases with <span className="text-emerald-600">AI Precision</span>
                </h1>
                <p className="text-lg sm:text-xl text-stone-600 mb-10 max-w-2xl mx-auto">
                  Upload a photo of your plant's leaf and get an instant diagnosis. Our advanced deep learning model supports 38+ disease categories with up to 96.6% accuracy.
                </p>
                <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <button
                    onClick={() => navigateTo('upload')}
                    className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-medium rounded-xl text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm transition-all hover:shadow-md"
                  >
                    Start Diagnosis
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </button>
                  <button
                    onClick={() => navigateTo('about')}
                    className="inline-flex items-center justify-center px-8 py-4 border border-stone-300 text-base font-medium rounded-xl text-stone-700 bg-white hover:bg-stone-50 shadow-sm transition-all"
                  >
                    Learn More
                  </button>
                </div>
                
                <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-8 border-t border-stone-200 pt-12">
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-emerald-100 text-emerald-600 mb-4">
                      <CheckCircle className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-medium text-stone-900">96.6% Accuracy</h3>
                    <p className="mt-2 text-sm text-stone-500 text-center">Powered by advanced transfer learning.</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-emerald-100 text-emerald-600 mb-4">
                      <Leaf className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-medium text-stone-900">38+ Categories</h3>
                    <p className="mt-2 text-sm text-stone-500 text-center">Identifies a wide range of plant species and diseases.</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <div className="flex items-center justify-center h-12 w-12 rounded-md bg-emerald-100 text-emerald-600 mb-4">
                      <AlertTriangle className="h-6 w-6" />
                    </div>
                    <h3 className="text-lg font-medium text-stone-900">Actionable Advice</h3>
                    <p className="mt-2 text-sm text-stone-500 text-center">Get immediate treatment recommendations.</p>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {currentPage === 'about' && (
            <motion.div
              key="about"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8 w-full"
            >
              <div className="bg-white rounded-2xl shadow-sm border border-stone-200 overflow-hidden">
                <div className="bg-emerald-600 px-6 py-10 sm:px-10 text-center">
                  <h2 className="text-3xl font-bold text-white mb-2">About PlantCare AI</h2>
                  <p className="text-emerald-100 max-w-2xl mx-auto">
                    Empowering farmers and plant enthusiasts with cutting-edge artificial intelligence.
                  </p>
                </div>
                <div className="px-6 py-8 sm:p-10 prose prose-stone max-w-none">
                  <h3>Our Mission</h3>
                  <p>
                    Plant diseases pose a significant threat to global food security and agricultural productivity. 
                    Early detection is crucial for effective treatment and preventing crop loss. PlantCare AI aims to 
                    democratize access to expert-level plant pathology through an easy-to-use web application.
                  </p>
                  
                  <h3>The Technology</h3>
                  <p>
                    Under the hood, PlantCare AI utilizes a state-of-the-art deep learning model based on the 
                    <strong> MobileNetV2</strong> architecture. This model was chosen for its optimal balance between 
                    high accuracy and computational efficiency, making it perfect for web and mobile applications.
                  </p>
                  
                  <ul>
                    <li><strong>Dataset:</strong> Trained on the comprehensive "New Plant Diseases Dataset" containing over 87,000 images.</li>
                    <li><strong>Transfer Learning:</strong> We leveraged pre-trained weights to accelerate learning and improve feature extraction.</li>
                    <li><strong>Architecture:</strong> Custom layers including GlobalAveragePooling2D and Dropout were added to prevent overfitting.</li>
                    <li><strong>Performance:</strong> Achieved a validation accuracy of ~96.6% across 38 distinct plant-disease classes.</li>
                  </ul>
                  
                  <h3>How It Works</h3>
                  <ol>
                    <li><strong>Upload:</strong> You provide an image of a plant leaf showing signs of distress.</li>
                    <li><strong>Preprocessing:</strong> The image is automatically resized and normalized to match our model's input requirements.</li>
                    <li><strong>Inference:</strong> The AI analyzes the visual patterns and compares them against its learned database.</li>
                    <li><strong>Diagnosis:</strong> You receive a detailed report including the plant species, identified disease, and actionable treatment steps.</li>
                  </ol>
                </div>
              </div>
            </motion.div>
          )}

          {currentPage === 'upload' && (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="flex-grow flex flex-col items-center justify-center px-4 py-12 sm:px-6 lg:px-8 w-full"
            >
              <div className="max-w-2xl w-full">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-stone-900">Upload Leaf Image</h2>
                  <p className="mt-2 text-stone-600">For best results, ensure the leaf is well-lit and clearly visible.</p>
                </div>

                <div className="bg-white rounded-2xl shadow-sm border border-stone-200 p-6 sm:p-10">
                  {!imagePreview ? (
                    <div 
                      className="border-2 border-dashed border-stone-300 rounded-xl p-12 text-center hover:bg-stone-50 transition-colors cursor-pointer relative"
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={(e) => {
                        e.preventDefault();
                        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                          handleImageSelect(e.dataTransfer.files[0]);
                        }
                      }}
                    >
                      <input 
                        type="file" 
                        accept="image/*" 
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        onChange={(e) => {
                          if (e.target.files && e.target.files[0]) {
                            handleImageSelect(e.target.files[0]);
                          }
                        }}
                      />
                      <UploadCloud className="mx-auto h-12 w-12 text-stone-400 mb-4" />
                      <p className="text-lg font-medium text-stone-700 mb-1">Drag and drop your image here</p>
                      <p className="text-sm text-stone-500 mb-4">or click to browse from your device</p>
                      <span className="inline-flex items-center px-4 py-2 border border-stone-300 shadow-sm text-sm font-medium rounded-md text-stone-700 bg-white hover:bg-stone-50">
                        Select File
                      </span>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      <div className="relative rounded-xl overflow-hidden bg-stone-100 border border-stone-200 aspect-video flex items-center justify-center">
                        <img 
                          src={imagePreview} 
                          alt="Selected leaf" 
                          className="max-h-full max-w-full object-contain"
                        />
                        <button 
                          onClick={() => {
                            setSelectedImage(null);
                            setImagePreview(null);
                          }}
                          className="absolute top-2 right-2 p-1.5 bg-white/80 backdrop-blur-sm rounded-full text-stone-700 hover:bg-white hover:text-red-600 transition-colors shadow-sm"
                        >
                          <X className="h-5 w-5" />
                        </button>
                      </div>
                      
                      {error && (
                        <div className="p-4 bg-red-50 text-red-700 rounded-lg text-sm flex items-start">
                          <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0" />
                          <p>{error}</p>
                        </div>
                      )}

                      <button
                        onClick={handleAnalyze}
                        disabled={isAnalyzing}
                        className={`w-full flex justify-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-base font-medium text-white ${
                          isAnalyzing ? 'bg-emerald-400 cursor-not-allowed' : 'bg-emerald-600 hover:bg-emerald-700'
                        } transition-colors`}
                      >
                        {isAnalyzing ? (
                          <span className="flex items-center">
                            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Analyzing Image...
                          </span>
                        ) : (
                          'Analyze Image'
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}

          {currentPage === 'result' && analysisResult && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className="max-w-4xl mx-auto px-4 py-12 sm:px-6 lg:px-8 w-full"
            >
              <div className="bg-white rounded-2xl shadow-sm border border-stone-200 overflow-hidden">
                <div className="grid grid-cols-1 md:grid-cols-2">
                  <div className="bg-stone-100 p-6 flex items-center justify-center border-b md:border-b-0 md:border-r border-stone-200">
                    {imagePreview && (
                      <img 
                        src={imagePreview} 
                        alt="Analyzed leaf" 
                        className="max-h-80 rounded-lg shadow-sm object-contain"
                      />
                    )}
                  </div>
                  <div className="p-6 sm:p-8">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-emerald-600 tracking-wide uppercase">Diagnosis Result</span>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                        {analysisResult.confidence}% Confidence
                      </span>
                    </div>
                    
                    {!analysisResult.isPlant ? (
                      <div className="mt-4">
                        <h3 className="text-2xl font-bold text-stone-900 mb-2">Not a Plant</h3>
                        <p className="text-stone-600">The uploaded image does not appear to contain a plant or leaf. Please try again with a clear photo of a plant leaf.</p>
                      </div>
                    ) : (
                      <>
                        <h3 className="text-2xl font-bold text-stone-900 mb-1">{analysisResult.plantName}</h3>
                        <div className="flex items-center mb-6">
                          <span className={`text-lg font-medium ${analysisResult.disease.toLowerCase() === 'healthy' ? 'text-emerald-600' : 'text-red-600'}`}>
                            {analysisResult.disease}
                          </span>
                        </div>
                        
                        <div className="prose prose-sm prose-stone mb-6">
                          <p>{analysisResult.description}</p>
                        </div>
                        
                        {analysisResult.disease.toLowerCase() !== 'healthy' && analysisResult.treatment && analysisResult.treatment.length > 0 && (
                          <div className="mb-6">
                            <h4 className="text-sm font-bold text-stone-900 uppercase tracking-wide mb-3 flex items-center">
                              <AlertTriangle className="h-4 w-4 mr-1.5 text-amber-500" />
                              Recommended Treatment
                            </h4>
                            <ul className="space-y-2">
                              {analysisResult.treatment.map((step: string, index: number) => (
                                <li key={index} className="flex items-start">
                                  <span className="flex-shrink-0 h-5 w-5 rounded-full bg-stone-100 text-stone-500 flex items-center justify-center text-xs font-medium mt-0.5 mr-2">
                                    {index + 1}
                                  </span>
                                  <span className="text-sm text-stone-700">{step}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {analysisResult.fertilizers && analysisResult.fertilizers.length > 0 && (
                          <div>
                            <h4 className="text-sm font-bold text-stone-900 uppercase tracking-wide mb-3 flex items-center">
                              <Sprout className="h-4 w-4 mr-1.5 text-emerald-500" />
                              Recommended Fertilizers
                            </h4>
                            <ul className="space-y-2">
                              {analysisResult.fertilizers.map((fertilizer: string, index: number) => (
                                <li key={index} className="flex items-start">
                                  <div className="flex-shrink-0 h-1.5 w-1.5 rounded-full bg-emerald-500 mt-2 mr-2"></div>
                                  <span className="text-sm text-stone-700">{fertilizer}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </>
                    )}
                    
                    <div className="mt-8 pt-6 border-t border-stone-200">
                      <button
                        onClick={resetUpload}
                        className="w-full flex justify-center items-center py-2.5 px-4 border border-stone-300 rounded-xl shadow-sm text-sm font-medium text-stone-700 bg-white hover:bg-stone-50 transition-colors"
                      >
                        <Camera className="h-4 w-4 mr-2" />
                        Analyze Another Plant
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
          {currentPage === 'assistant' && (
            <motion.div
              key="assistant"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
              className="flex-grow flex flex-col max-w-4xl mx-auto w-full px-4 py-6 sm:px-6 lg:px-8 h-[calc(100vh-4rem)]"
            >
              <div className="bg-white rounded-2xl shadow-sm border border-stone-200 flex flex-col h-full overflow-hidden">
                <div className="bg-emerald-600 px-6 py-4 flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-bold text-white flex items-center">
                      <MessageSquare className="h-5 w-5 mr-2" />
                      PlantCare Voice Assistant
                    </h2>
                    <p className="text-emerald-100 text-sm">Ask me about plant care, diseases, or fertilizers</p>
                  </div>
                </div>
                
                <div className="flex-grow overflow-y-auto p-6 space-y-6 bg-stone-50">
                  {chatMessages.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-stone-500 space-y-4">
                      <div className="h-16 w-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-2">
                        <Mic className="h-8 w-8" />
                      </div>
                      <p className="text-center max-w-sm">
                        Tap the microphone to ask a question, or type it below. Try asking: <br/>
                        <span className="italic text-stone-600">"Which type of fertilizer should I use for a tomato plant?"</span>
                      </p>
                    </div>
                  ) : (
                    chatMessages.map((msg, idx) => (
                      <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] rounded-2xl px-5 py-3 ${
                          msg.role === 'user' 
                            ? 'bg-emerald-600 text-white rounded-br-sm' 
                            : 'bg-white border border-stone-200 text-stone-800 rounded-bl-sm shadow-sm'
                        }`}>
                          <p className="whitespace-pre-wrap">{msg.text}</p>
                          {msg.audio && (
                            <button 
                              onClick={() => playAudio(msg.audio!)}
                              className="mt-2 flex items-center text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md hover:bg-emerald-100 transition-colors"
                            >
                              <Volume2 className="h-3 w-3 mr-1" />
                              Play Audio
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  )}
                  {isProcessingVoice && (
                    <div className="flex justify-start">
                      <div className="bg-white border border-stone-200 text-stone-500 rounded-2xl rounded-bl-sm px-5 py-3 shadow-sm flex items-center space-x-2">
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                        <div className="w-2 h-2 bg-stone-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                      </div>
                    </div>
                  )}
                  <div ref={chatEndRef} />
                </div>

                <div className="p-4 bg-white border-t border-stone-200">
                  {error && (
                    <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm flex items-start">
                      <AlertTriangle className="h-4 w-4 mr-2 flex-shrink-0 mt-0.5" />
                      <p>{error}</p>
                    </div>
                  )}
                  <div className="flex items-center space-x-2">
                    <button
                      type="button"
                      onMouseDown={startRecording}
                      onMouseUp={stopRecording}
                      onMouseLeave={stopRecording}
                      onTouchStart={startRecording}
                      onTouchEnd={stopRecording}
                      className={`flex-shrink-0 h-12 w-12 rounded-full flex items-center justify-center transition-all ${
                        isRecording 
                          ? 'bg-red-500 text-white shadow-lg scale-110 animate-pulse' 
                          : 'bg-emerald-100 text-emerald-600 hover:bg-emerald-200'
                      }`}
                      title="Hold to talk"
                    >
                      {isRecording ? <Square className="h-5 w-5 fill-current" /> : <Mic className="h-5 w-5" />}
                    </button>
                    
                    <form onSubmit={handleTextSubmit} className="flex-grow flex relative">
                      <input
                        type="text"
                        value={textInput}
                        onChange={(e) => setTextInput(e.target.value)}
                        placeholder="Type your question..."
                        className="w-full pl-4 pr-12 py-3 bg-stone-100 border-transparent rounded-xl focus:bg-white focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 transition-colors"
                        disabled={isProcessingVoice || isRecording}
                      />
                      <button
                        type="submit"
                        disabled={!textInput.trim() || isProcessingVoice || isRecording}
                        className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-emerald-600 hover:text-emerald-700 disabled:text-stone-400 transition-colors"
                      >
                        <Send className="h-5 w-5" />
                      </button>
                    </form>
                  </div>
                  <p className="text-center text-xs text-stone-400 mt-3">
                    Hold the microphone button to speak, or type your message.
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-stone-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center mb-4">
            <Leaf className="h-5 w-5 text-emerald-600 mr-2" />
            <span className="text-lg font-bold text-stone-800 tracking-tight">PlantCare AI</span>
          </div>
          <p className="text-sm text-stone-500">
            &copy; {new Date().getFullYear()} PlantCare AI. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
